package com.spring.project.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.project.dto.user.UserDTO;
import com.spring.project.service.UserService;

import javax.servlet.http.HttpSession;

@RestController
@RequestMapping("/api")
public class UserController {

	@Autowired
	UserService userService;

	// 로그인 기능
	@PostMapping("/login")
	public Map<String, Object> login(@RequestBody UserDTO userDTO, HttpSession session){

		Map<String, Object> map = new HashMap<>();

		System.out.println("전달받은 id: " + userDTO.getId());
		System.out.println("전달받은 password: " + userDTO.getPassword());

		UserDTO loginUser = userService.login(userDTO);

		if (loginUser != null) {
			session.setAttribute("userSession", loginUser);
			map.put("message", "로그인 성공!");
			map.put("success", true);
		} else {
			map.put("message", "아이디 또는 비밀번호가 일치하지 않습니다.");
			map.put("success", false);
		}
		return map;
	}

	//로그아웃 기능
	@PostMapping("/logout")
	public Map<String, Object> logout(HttpSession session){
		Map<String, Object> map = new HashMap<String, Object>();

		session.invalidate();

		map.put("success", true);
		map.put("message", "로그아웃 성공!");
		return map;
	}

	//회원가입 기능
	@PostMapping("/signup")
	public Map<String, Object> singup(@RequestBody UserDTO userDTO){

		Map<String, Object> map = new HashMap<String, Object>();

		System.out.println("회원가입 요청 데이터: " + userDTO);

		try {
			int result = userService.signup(userDTO);
			System.out.println("insert 결과: " + result);

			if (result > 0) {
				map.put("success", true);
				map.put("message", "회원가입 성공");
			} else {
				map.put("success", false);
				map.put("message", "회원가입 실패");
			}
		} catch (Exception e) {
			e.printStackTrace(); // 여기에 진짜 이유 나옴
			map.put("success", false);
			map.put("message", "예외 발생: " + e.getMessage());
		}
		return map;
	}

	//user_type 확인기능
	@GetMapping("/session-check")
	public Map<String, Object> sessionCheck(HttpSession session) {
		Map<String, Object> map = new HashMap<>();
		UserDTO loginUser = (UserDTO) session.getAttribute("userSession");

		if (loginUser != null) {
			map.put("nickname", loginUser.getNickname());
			map.put("userType", loginUser.getUser_type());
			map.put("success", true);
		} else {
			map.put("success", false);
			map.put("message", "세션 없음");
		}
		System.out.println(loginUser.getUser_type());
		return map;
	}



	@PostMapping("/signupp")
	public Map<String, Object> signup(@RequestBody UserDTO userDTO, HttpSession session){

		System.out.println("전달 데이터  : " + userDTO.toString());

		return null;

	}
}
