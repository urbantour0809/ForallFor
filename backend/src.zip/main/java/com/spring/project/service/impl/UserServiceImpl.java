package com.spring.project.service.impl;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.project.dto.user.UserDTO;
import com.spring.project.repository.UserRepository;
import com.spring.project.service.UserService;


@Service("userService")
public class UserServiceImpl implements UserService{

    @Autowired
    private UserRepository UserRepository;

    @Override
    public UserDTO login(UserDTO user) {
        return UserRepository.login(user);
    }

    @Override
    public int signup(UserDTO user) {
        return UserRepository.signup(user);
    }



}
