package com.spring.project.service;
import com.spring.project.dto.user.*;

public interface UserService {
    //로그인
    public UserDTO login(UserDTO user);
    //회원가입
    public int signup(UserDTO user);
}
